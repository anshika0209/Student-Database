# Student Managment System
Developed Student mnaegment system using Visual C++ and MySql databse.
Feature in project:
1. Created table.
2.Inserted Coloums in Table.
3. We can fill :
  1. Student Information like,Student Id,Addresse,Email,mobileNo.
  2. Guardians Information like,Name,LastName,Email etc.
  3. Course with course code,Faulty Menber Information etc.
  4. Subjects with there marks and their tota and ranking of student.
